<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
    <li class="nav-item">
    <a href="/admin/dosen" class="nav-link">
        <i class="nav-icon fas fa-fingerprint"></i>
        <p>
        Dosen CRUD
        </p>
    </a>
    </li>
    <li class="nav-item">
    <a href="/admin/matakuliah" class="nav-link">
        <i class="nav-icon fas fa-fingerprint"></i>
        <p>
        Matakuliah CRUD
        </p>
    </a>
    </li>
</ul>